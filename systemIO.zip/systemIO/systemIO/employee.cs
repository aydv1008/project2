﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace systemIO
{
    class employee
    {
        public int emp_id, dept_id;
        public long phone;
        public string emp_name, email;
        public employee()
        {
            Console.WriteLine("enter employee ID");
            emp_id = int.Parse(Console.ReadLine());

            Console.WriteLine("enter employee name");
            emp_name = Console.ReadLine();

            Console.WriteLine("enter phone number");
            phone = long.Parse(Console.ReadLine());

            Console.WriteLine("enter department ID ");
            dept_id = int.Parse(Console.ReadLine());

            Console.WriteLine("enter employee email ID");
            email = Console.ReadLine();

        }
        public string displayemp()
        {
            return (emp_id.ToString().PadLeft(20) + " | " + emp_name.PadLeft(20) + "|" + phone.ToString().PadLeft(20) + "|" + dept_id.ToString().PadLeft(20) + "|" + email.PadLeft(20));

        }
    }
}
