﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace systemIO
{
    class projects
    {
        public int p_id, m_id;
        public string p_name;
        public projects()
        {
            Console.WriteLine("enter project ID ");
            p_id = int.Parse(Console.ReadLine());

            Console.WriteLine("enter project name");
            p_name = Console.ReadLine();

            Console.WriteLine("enter manager ID");
            m_id= int.Parse(Console.ReadLine());

        }
        public string displayproj()
        {
            return (p_id.ToString().PadLeft(20) + " | " + p_name.PadLeft(20) + "|" + m_id.ToString().PadLeft(20));
        }
    }
}
